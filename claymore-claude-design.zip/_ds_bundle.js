/* @ds-bundle: {"namespace":"Claymore","components":[{"name":"Button","sourcePath":"components/actions/Button/Button.jsx"},{"name":"Card","sourcePath":"components/layout/Card/Card.jsx"},{"name":"Eyebrow","sourcePath":"components/type/Eyebrow/Eyebrow.jsx"},{"name":"Headline","sourcePath":"components/type/Headline/Headline.jsx"},{"name":"Section","sourcePath":"components/layout/Section/Section.jsx"}],"sourceHashes":{"components/actions/Button/Button.jsx":"140ccc0503e8","components/actions/Button/Button.d.ts":"c8ab088fb131","components/actions/Button/Button.prompt.md":"14408f476bfa","components/layout/Card/Card.jsx":"586ed9c5c7a5","components/layout/Card/Card.d.ts":"e05ec7ad6901","components/layout/Card/Card.prompt.md":"f37c2bcdcd44","components/type/Eyebrow/Eyebrow.jsx":"f71fa7f5b073","components/type/Eyebrow/Eyebrow.d.ts":"47cc0a2f521d","components/type/Eyebrow/Eyebrow.prompt.md":"9c24dced43ac","components/type/Headline/Headline.jsx":"b7d36e191f92","components/type/Headline/Headline.d.ts":"e8ea3df0a833","components/type/Headline/Headline.prompt.md":"0041ccb733bd","components/layout/Section/Section.jsx":"2667426483c6","components/layout/Section/Section.d.ts":"c7dfb5e1d527","components/layout/Section/Section.prompt.md":"f3bf9d2556c1"},"inlinedExternals":[],"builtBy":"cc-design-sync"} */
"use strict";
var Claymore = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // dist/index.js
  var index_exports = {};
  __export(index_exports, {
    Button: () => Button,
    Card: () => Card,
    Eyebrow: () => Eyebrow,
    Headline: () => Headline,
    Section: () => Section
  });
  init_define_import_meta_env();
  var import_jsx_runtime = __toESM(require_react_shim(), 1);
  var cx = (...c) => c.filter(Boolean).join(" ");
  function Headline({ size = "xl", as, accent, children, className, ...rest }) {
    const Tag = as || (size === "sub" ? "h2" : "h1");
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tag, { ...rest, className: cx("cl-headline", "cl-headline-" + size, className), children: [
      children,
      accent && size !== "sub" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
        " ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "cl-accent", children: accent })
      ] }) : null
    ] });
  }
  function Eyebrow({ as = "p", className, children, ...rest }) {
    const Tag = as;
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { ...rest, className: cx("cl-eyebrow", className), children });
  }
  function Button({ variant = "primary", href, className, children, type, ...rest }) {
    const cls = cx("cl-btn", "cl-btn-" + variant, className);
    if (href) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href, className: cls, ...rest, children });
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: type || "button", ...rest, className: cls, children });
  }
  function Card({ eyebrow, title, footer, tinted, className, children, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { ...rest, className: cx("cl-card", tinted && "cl-card-tinted", className), children: [
      eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: eyebrow }) : null,
      title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { className: "cl-card-title", children: title }) : null,
      children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cl-card-body", children }) : null,
      footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cl-card-footer", children: footer }) : null
    ] });
  }
  function Section({ tone = "light", as = "section", className, children, ...rest }) {
    const Tag = as;
    const dark = tone === "navy" || tone === "deep";
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { ...rest, "data-theme": dark ? "navy" : "light", className: cx("cl-section", (tone === "mist" || tone === "deep") && "cl-section-alt", className), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cl-section-inner", children }) });
  }
  return __toCommonJS(index_exports);
})();
window.Claymore=Claymore.__dsMainNs?Object.assign({},Claymore,Claymore.__dsMainNs,{__dsMainNs:undefined}):Claymore;
