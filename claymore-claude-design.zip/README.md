## Claymore conventions (read before building)

Claymore is the brand of Steven Saunders (board advisory) and The AI Sports Guy (AI adoption workshops). Essence: **Clarity**. Calm, confident, editorial: navy anchors, white space carries, one blue means "click me".

### Setup
- Load `styles.css` (tokens, Google Fonts for Unbounded, Kaushan Script and Barlow, and component CSS). Components are on `window.Claymore`: `Headline`, `Eyebrow`, `Button`, `Card`, `Section`.
- No provider is needed. The page is light by default. Put heroes, banners and footers in `<Section tone="navy">` or `tone="deep"`. These set `data-theme="navy"` and every semantic token inside flips: headlines and text turn white, the script accent turns silver, and the primary Button turns white with navy text. You can also put `data-theme="navy"` on your own wrapper with `background: var(--surface)`.

### Styling idiom: CSS custom properties, never hex
- Semantic: `--surface` `--surface-alt` `--ink` `--ink-muted` `--display` `--accent-script` `--action` `--action-hover` `--on-action` `--link` `--rule` `--rule-strong`
- Palette: `--claymore-navy` `--claymore-navy-deep` `--claymore-navy-bright` `--silver` `--mist` `--white` `--charcoal` `--slate` `--action-blue` `--light-border`
- Space: `--space-1` 8, `--space-2` 16, `--space-3` 24, `--space-4` 32, `--space-6` 48, `--space-12` 96. Radius: `--radius-sm` 2px for buttons, `--radius-md` 4px for cards.
- Fonts: `--font-headline` (Unbounded), `--font-accent` (Kaushan Script), `--font-body` (Barlow).
- Layout helpers: `.cl-row` (wrapping flex row), `.cl-grid` (auto-fit card grid), `.cl-lead` (19px lead paragraph).

### Hard rules
- Every headline uses `<Headline>`: Unbounded 700, uppercase. Never set a headline in Barlow.
- Use the script accent (`accent` prop, the last 1-3 words) on ONE headline per page, slide or graphic. Never use it in body text, buttons, labels or sub-heads.
- Use action-blue (`--action`, `--link`) only on clickable things, with one primary Button per section.
- Never use silver text on white or mist, and never put action-blue on navy.
- Add no other hues: no red, green, orange or gradients, and no drop shadows. Use a 1px `--rule` border.
- Use generous white space: sections pad `--space-12`.

### Example
```jsx
const { Section, Eyebrow, Headline, Button, Card } = window.Claymore;
<>
  <Section tone="navy">
    <Eyebrow>AI adoption workshops</Eyebrow>
    <Headline size="lg" accent="Clarity will.">AI won't fix your content.</Headline>
    <p className="cl-lead">Half-day sessions that turn a nervous team into a confident one.</p>
    <div className="cl-row"><Button>Book a workshop</Button><Button variant="secondary">See the PITCH kit</Button></div>
  </Section>
  <Section tone="mist">
    <div className="cl-grid"><Card title="Advisory">Board-level content strategy.</Card><Card tinted title="Workshops">AI for sports media teams.</Card></div>
  </Section>
</>
```

# Claymore (claymore-ds@1.0.0)

This design system is the published claymore-ds React library, bundled as a single
browser global. All 5 components are the real upstream code.

## Where things are

- `_ds_bundle.js` — the whole-DS bundle at the project root; loads every component to `window.Claymore`. First line is a `/* @ds-bundle: … */` metadata header.
- `styles.css` — the single stylesheet entry: it `@import`s the tokens, fonts, and component styles (`_ds_bundle.css`). Link this one file.
- `components/<group>/<Name>/<Name>.prompt.md` (example JSX + variants), `<Name>.d.ts` (types), `<Name>.html` (variant grid).
- `tokens/*.css` — CSS custom properties, names verbatim from upstream.
- `fonts/` — `@font-face` files + `fonts.css` (when the package ships fonts).
- `guidelines/` — the design system's own usage guidance (1 doc(s), see `guidelines/index.md`). Read these before composing larger layouts.

For a specific component, `read_file("components/<group>/<Name>/<Name>.prompt.md")`.

## Loading

Add these two lines to your page once (React must be on the page first):

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
```

Components are then available at `window.Claymore.*`. Mount into a dedicated child node (e.g. `<div id="ds-root">`), not the host page's own React root, so the two trees don't collide:

```jsx
const { Button } = window.Claymore;
ReactDOM.createRoot(document.getElementById('ds-root')).render(<Button />);
```

## Tokens

34 CSS custom properties from claymore-ds. Names are
preserved verbatim from upstream. They are declared inside `_ds_bundle.css` (this DS ships one compiled stylesheet rather than separate token files).

- **color** (2): `--surface`, `--surface-alt`
- **spacing** (6): `--space-1`, `--space-2`, `--space-3`, …
- **typography** (3): `--font-headline`, `--font-accent`, `--font-body`
- **radius** (3): `--radius-none`, `--radius-sm`, `--radius-md`
- **other** (20): `--claymore-navy`, `--claymore-navy-deep`, `--claymore-navy-bright`, …

## Components

### actions
- `Button` — The one clear action in a section. Primary is action-blue on light and turns white with navy text inside a navy Section.

### layout
- `Card` — A bordered panel for a service, workshop or offer: eyebrow, Unbounded caps title, body, footer. 1px rule border, no shadow.
- `Section` — A full-width band with generous padding and a centred 1120px column. navy and deep set data-themenavy so everything inside reads on dark.

### type
- `Eyebrow` — A short uppercase label above a headline or card title: Barlow 600, 13px, 0.14em tracking, in ink-muted.
- `Headline` — The brand's signature headline: Unbounded 700, always uppercase, with an optional Kaushan Script accent on the final phrase.
