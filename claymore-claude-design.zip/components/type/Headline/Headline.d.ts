import * as React from 'react';

/**
 * Headline — from claymore-ds@1.0.0.
 */
export interface HeadlineProps {
  /** xl = 56px hero, lg = 40px, md = 30px (mobile H1), sub = 24px Unbounded 600 sub-head (never takes an accent). */
  size?: "xl" | "lg" | "md" | "sub";
  /** Heading element; defaults to h1 (h2 for sub). */
  as?: "h1" | "h2" | "h3";
  /** The final 1-3 words, set in Kaushan Script. Use on ONE headline per page, slide or graphic. */
  accent?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Headline: React.ComponentType<HeadlineProps>;
