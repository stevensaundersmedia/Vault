Headline from claymore-ds. Use via `window.Claymore.Headline` (bundle loaded from the root `_ds_bundle.js`).

The brand's signature moment: Unbounded 700 in uppercase, with an optional Kaushan Script accent on the final phrase. Pass the headline text as children and the last one to three words as `accent`, on ONE headline per page, slide or graphic. Pick a size: `xl` for the desktop hero (56px), `lg` for a section H1 (40px) or `md` for 30px. `sub` gives a 24px Unbounded 600 sub-head, which never takes an accent. `xl` and `lg` drop to 30px under 640px. Colours follow the section theme: navy text with a navy-bright accent on light, white text with a silver accent on navy.

Don't use the accent on more than one headline per piece, put it mid-sentence, set a headline in Barlow, or write it in title case expecting mixed case (the component uppercases it).

## Props

```ts
interface HeadlineProps {
  /** xl = 56px hero, lg = 40px, md = 30px (mobile H1), sub = 24px Unbounded 600 sub-head (never takes an accent). */
  size?: "xl" | "lg" | "md" | "sub";
  /** Heading element; defaults to h1 (h2 for sub). */
  as?: "h1" | "h2" | "h3";
  /** The final 1-3 words, set in Kaushan Script. Use on ONE headline per page, slide or graphic. */
  accent?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```
