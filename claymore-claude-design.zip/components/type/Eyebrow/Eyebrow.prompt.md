Eyebrow from claymore-ds. Use via `window.Claymore.Eyebrow` (bundle loaded from the root `_ds_bundle.js`).

A short uppercase label above a headline or card title: Barlow 600 at 13px with 0.14em tracking, in `ink-muted`. Keep it to two to four words that name the category ("Fractional leadership"), never a sentence. Use one per block.

## Props

```ts
interface EyebrowProps {
  as?: "p" | "span" | "div";
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```
