import * as React from 'react';

/**
 * Eyebrow — from claymore-ds@1.0.0.
 */
export interface EyebrowProps {
  as?: "p" | "span" | "div";
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Eyebrow: React.ComponentType<EyebrowProps>;
