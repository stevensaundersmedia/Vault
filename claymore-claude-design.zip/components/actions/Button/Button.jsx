// Re-export of claymore-ds@1.0.0 Button. Implementation is in the root _ds_bundle.js (window.Claymore).
Object.assign(window, { Button: window.Claymore.Button });
