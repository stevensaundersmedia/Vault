Button from claymore-ds. Use via `window.Claymore.Button` (bundle loaded from the root `_ds_bundle.js`).

The one clear action in a section. `primary` uses the `action` fill: action-blue with white text on light, white with navy text on navy. Use one primary per section. `secondary` is outlined in `rule-strong` for a lesser alternative. Pass `href` to render a link. Start labels with a verb, in sentence case: "Book a call". Never use the script accent on a button, and never colour a button action-blue on navy (the navy theme swaps it for you).

## Props

```ts
interface ButtonProps {
  /** primary = action fill (one per section); secondary = outlined in rule-strong. */
  variant?: "primary" | "secondary";
  /** Renders an <a> instead of a <button>. */
  href?: string;
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```
