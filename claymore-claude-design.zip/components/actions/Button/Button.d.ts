import * as React from 'react';

/**
 * Button — from claymore-ds@1.0.0.
 * @replaces button
 */
export interface ButtonProps {
  /** primary = action fill (one per section); secondary = outlined in rule-strong. */
  variant?: "primary" | "secondary";
  /** Renders an <a> instead of a <button>. */
  href?: string;
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Button: React.ComponentType<ButtonProps>;
