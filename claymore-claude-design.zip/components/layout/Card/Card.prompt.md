Card from claymore-ds. Use via `window.Claymore.Card` (bundle loaded from the root `_ds_bundle.js`).

A bordered panel for a service, workshop or offer: an optional `eyebrow`, an Unbounded caps `title`, body as children and an optional `footer` (usually a secondary Button or a link). It has a 1px `rule` border, `radius-md` corners and no shadow. Set `tinted` for a mist fill on white sections. Lay cards out in `.cl-grid` and keep sibling cards to the same parts so their edges align.

## Props

```ts
interface CardProps {
  eyebrow?: React.ReactNode;
  title?: React.ReactNode;
  /** Usually a secondary Button or a link. */
  footer?: React.ReactNode;
  /** Mist fill, no border - for cards on a white section. */
  tinted?: boolean;
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```
