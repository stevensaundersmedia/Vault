import * as React from 'react';

/**
 * Card — from claymore-ds@1.0.0.
 */
export interface CardProps {
  eyebrow?: React.ReactNode;
  title?: React.ReactNode;
  /** Usually a secondary Button or a link. */
  footer?: React.ReactNode;
  /** Mist fill, no border - for cards on a white section. */
  tinted?: boolean;
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Card: React.ComponentType<CardProps>;
