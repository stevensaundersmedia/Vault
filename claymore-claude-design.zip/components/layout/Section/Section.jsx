// Re-export of claymore-ds@1.0.0 Section. Implementation is in the root _ds_bundle.js (window.Claymore).
Object.assign(window, { Section: window.Claymore.Section });
