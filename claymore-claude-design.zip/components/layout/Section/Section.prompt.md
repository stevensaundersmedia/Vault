Section from claymore-ds. Use via `window.Claymore.Section` (bundle loaded from the root `_ds_bundle.js`).

A full-width band with the brand's generous padding (`space-12`, or `space-6` on mobile) and a centred 1120px column that stacks children with a `space-3` gap. `tone`: `light` (white, default), `mist` (tinted alternate), `navy` (claymore-navy) or `deep` (claymore-navy-deep, for footers). `navy` and `deep` set `data-theme="navy"`, so every component and token inside reads correctly on dark. Alternate light and mist down a page, and keep navy for heroes, banners and footers. On The AI Sports Guy pages, navy bands can be used more boldly.

## Props

```ts
interface SectionProps {
  /** light = white, mist = tinted, navy = claymore-navy, deep = claymore-navy-deep. navy/deep switch every token inside to th */
  tone?: "light" | "mist" | "navy" | "deep";
  as?: "div" | "section" | "header" | "footer";
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```
