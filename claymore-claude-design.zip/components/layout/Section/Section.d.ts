import * as React from 'react';

/**
 * Section — from claymore-ds@1.0.0.
 */
export interface SectionProps {
  /** light = white, mist = tinted, navy = claymore-navy, deep = claymore-navy-deep. navy/deep switch every token inside to th */
  tone?: "light" | "mist" | "navy" | "deep";
  as?: "div" | "section" | "header" | "footer";
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Section: React.ComponentType<SectionProps>;
