# Claymore brand book

Claymore is the visual system for **Steven Saunders** (board advisory and fractional leadership) and **The AI Sports Guy** (AI adoption workshops and the PITCH kit). The colours come from the Scottish Claymores. The brand's essence is **Clarity**: calm, confident, editorial. Navy anchors the identity, plenty of light space carries the content, and one blue does the talking for actions.

## Setup

- Load `tokens.css`, then `components/bundle.css` (it imports Unbounded, Kaushan Script and Barlow from Google Fonts), then React 18 and `components/bundle.js`. Components live on `window.Claymore`.
- Pages default to the `light` theme. Wrap hero, banner and footer bands in `<Section tone="navy">` or `tone="deep"`. That sets `data-theme="navy"` on the band, and every semantic token inside it switches: `display` and `ink` turn white, `accent-script` turns silver, `action` becomes a white button with navy text. Don't recolour things by hand inside a navy band.
- Style your own layout with tokens: `var(--surface)`, `var(--ink)`, `var(--space-4)` and so on. Never hard-code hex values or near-misses, and never add hues. There are no reds, greens, oranges or gradients.

## Content fundamentals

- The voice is vibrant, literate and specific, with dry wit that earns its place. It is never corporate, never bland, never breathless.
- Headlines land a thought rather than label a topic. Example: "AI won't fix your content. *Clarity will.*"
- Use one clear message and one clear action per section.
- Write in British English, first person ("I") for Steven Saunders and direct "you" for the reader. No emoji.

## Colour

| Role | Token |
|---|---|
| Page ground | `surface` (white), with `surface-alt` (mist) for alternating sections and cards |
| H1 and display | `display` (navy on light) |
| Body and sub-heads | `ink` (charcoal) |
| Captions, eyebrows | `ink-muted` (slate) |
| Primary CTA | `action` fill, `on-action` text, `action-hover` on hover |
| Links | `link` |
| Borders and dividers | `rule`; outlines that must read use `rule-strong` |

- `action-blue` (via `action` and `link`) is scarce on purpose. Use it only on things a person can click. If everything is blue, nothing looks clickable.
- Never set `silver` as text on white or mist (1.65:1). It is for rules on light and for text on navy only.
- Never put `action-blue` on navy (1.9:1). On navy bands the `navy` theme already swaps the CTA to white.
- Charts take series in this order: `claymore-navy`, `claymore-navy-bright`, `action-blue`, `slate`, `silver`. Gridlines use `light-border` and axis labels use `slate`.
- If a form needs an error state, keep it minimal and flag it to Steven. The palette has no status colours.

## Typography

- **Headlines** use `Headline`: Unbounded 700, ALWAYS uppercase, tracking 0.01em, leading about 1.1. Make them big. The headline is the brand's signature moment. Sizes are `display-xl` 56px (desktop hero), `display-lg` 40px and `display-mobile` 30px. Sub-heads and card titles use Unbounded 600 caps (`heading` 24px, `card-title` 18px).
- **The script accent** is the signature move. Pass the last one to three words of ONE headline per page, slide or graphic as `accent`. It renders in Kaushan Script at about 1.45x the headline size, in mixed case, rotated -4°, in `accent-script`. Never use it in body text, buttons, labels or sub-heads, and drop it under about 24px.
- **Barlow** carries everything else: `body` 16px or `body-lg` 19px at weight 400, `eyebrow` at 600 uppercase with 0.14em tracking, and `button` at 600. Barlow never carries a headline alone, because plain sans headlines read as a medical pamphlet.
- Other sizes: social graphic H1 76–84px, title slide H1 about 90px, content slide H2 about 48px, A4 one-pager H1 about 40px. Body runs 26–28px on social graphics.

## Layout, borders and space

- Use generous white space and favour restraint over decoration. Section padding is `space-12` (96px), dropping to `space-6` on mobile. Grid gutters are `space-4`.
- Keep the grid clean and the type hierarchy strong. Use no drop shadows: a 1px `rule` border beats a shadow. Corners are crisp: `radius-sm` for buttons and inputs, `radius-md` for cards, `radius-none` for bands.
- Focus rings are 2px solid `action`, offset 2px.
- Don't use stock clip-art.

## Logo and iconography

- No logo file exists yet. Set the name "Steven Saunders" in Unbounded caps in `claymore-navy` (white on navy) and don't draw a mark.
- No icon set is defined. Prefer words. If an icon is unavoidable, use a single-weight line icon in `ink` and flag it.

## Example

```jsx
const { Section, Eyebrow, Headline, Button } = window.Claymore;
<Section tone="navy">
  <Eyebrow>AI adoption workshops</Eyebrow>
  <Headline accent="Clarity will.">AI won't fix your content.</Headline>
  <p className="cl-lead">Half-day sessions that turn a nervous newsroom into a confident one.</p>
  <div className="cl-row"><Button href="#book">Book a workshop</Button><Button variant="secondary">See the PITCH kit</Button></div>
</Section>
```
