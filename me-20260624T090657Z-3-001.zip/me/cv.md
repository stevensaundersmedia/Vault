# CV

*[Paste your full CV here. This is the single source of truth used across all AI sessions — interview prep, bio generation, proposal writing, and opportunity assessment all draw from this file.]*

---

## How this file is used

- **Interview prep:** AI reads this alongside `workflows/interview-prep.md` to prepare tailored responses
- **Bio generation:** AI draws from this to create short, medium, and long bios in the voice specified in `me/voice.md`
- **Opportunity assessment:** AI compares incoming roles against this to identify fit and gaps
- **Proposal writing:** AI uses career history to establish credibility and frame relevant experience

---

## Sections to include when you populate this

- Name and contact (personal email only — no employer email)
- Professional summary (2–3 sentences in your voice)
- Career history (most recent first, with achievements not just responsibilities)
- Key skills and specialisms
- Education
- Speaking, conferences, publications (if applicable)
- Notable projects or case studies (non-confidential)

---

*Add your CV content below this line.*
