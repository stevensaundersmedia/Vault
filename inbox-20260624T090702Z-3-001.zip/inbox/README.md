# Inbox

This is the capture zone. Drop raw notes here without worrying about structure.

---

## How to use it

1. **After a call or meeting:** Drop raw notes as `YYYY-MM-DD-[name or topic].md`
2. **Stray thoughts / ideas:** Drop them here with a date prefix and process later
3. **Notion migration:** Export notes from Notion and drop them here to be sorted

---

## Processing the inbox

Run this prompt weekly (or whenever the inbox gets full):

> "Look at everything in my `inbox/` folder. For each file:
> 1. Tell me what it is and where it should go in the vault
> 2. Process any call notes using `templates/call-note.md`
> 3. Flag any actions or follow-ups I might have missed
> 4. Ask me before moving or deleting anything"

---

## Notion migration notes

When exporting from Notion:
- Export as Markdown where possible
- Drop all files into `inbox/notion-export/` as a subfolder
- Ask AI to categorise and redistribute them across the vault structure
- Expect this to take several sessions — don't try to do it all at once
